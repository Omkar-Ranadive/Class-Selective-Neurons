import torch
from torch import nn
from torch.nn.modules.activation import ReLU
import torchvision.models as models
from PIL import Image
from torchvision import transforms
import torchvision.datasets as datasets
from torchvision.models.resnet import resnet50
from constants import DATA_PATH, IMGNET_PATH
import numpy as np 
from torchvision.models.resnet import Bottleneck as Bottleneck
from torchvision.models.resnet import BasicBlock as BasicBlock
import utils 
import time
from tqdm import tqdm
import copy 
import argparse
import natsort 
import re 
import os 
import sys 
from torchvision.models.feature_extraction import get_graph_node_names
from torchvision.models.feature_extraction import create_feature_extractor


class NewModel(nn.Module):
    def __init__(self, arch, return_nodes, *args):
        super().__init__(*args)
        self.features = {}
     
        self.model = models.__dict__[arch]()
        layers = [self.model.layer1, self.model.layer2, self.model.layer3, self.model.layer4]
        for k in return_nodes.keys():
            splits = k.split(".")
            l_num = int(splits[0][-1])
            bn_num = int(splits[1])
            layers[l_num-1][bn_num].register_forward_hook(self.forward_hook(k))

        # if arch == 'resnet50': 
        #     self.model = models.__dict__[arch]()
        #     # Hooks for module 4 
        #     self.model.layer1[0].register_forward_hook(self.forward_hook('layer1.0.relu_2'))
        #     self.model['layer1'][1].register_forward_hook(self.forward_hook('layer1.1.relu_2'))
        #     self.model['layer1'][2].register_forward_hook(self.forward_hook('layer1.2.relu_2'))

        #     # Hooks for module 5 
        #     self.model.layer2[0].register_forward_hook(self.forward_hook('layer2.0.relu_2'))
        #     self.model.layer2[1].register_forward_hook(self.forward_hook('layer2.1.relu_2'))
        #     self.model.layer2[2].register_forward_hook(self.forward_hook('layer2.2.relu_2'))
        #     self.model.layer2[3].register_forward_hook(self.forward_hook('layer2.3.relu_2'))

        #     # Hooks for module 6
        #     self.model.layer3[0].register_forward_hook(self.forward_hook('layer3.0.relu_2'))
        #     self.model.layer3[1].register_forward_hook(self.forward_hook('layer3.1.relu_2'))
        #     self.model.layer3[2].register_forward_hook(self.forward_hook('layer3.2.relu_2'))
        #     self.model.layer3[3].register_forward_hook(self.forward_hook('layer3.3.relu_2'))            
        #     self.model.layer3[4].register_forward_hook(self.forward_hook('layer3.4.relu_2'))            
        #     self.model.layer3[5].register_forward_hook(self.forward_hook('layer3.5.relu_2'))            

        #     # Hooks for module 7
        #     self.model.layer4[0].register_forward_hook(self.forward_hook('layer4.0.relu_2'))
        #     self.model.layer4[1].register_forward_hook(self.forward_hook('layer4.1.relu_2'))
        #     self.model.layer4[2].register_forward_hook(self.forward_hook('layer4.2.relu_2'))

        # elif arch == 'resnet18': 
        #     # Hooks for module 4
        #     self.model.layer1[0].register_forward_hook(self.forward_hook('layer1.0.relu_2'))
        #     self.model.layer1[1].register_forward_hook(self.forward_hook('layer1.1.relu_2'))
            
        #     # Hooks for module 5
        #     self.model.layer2[0].register_forward_hook(self.forward_hook('layer2.0.relu_2'))
        #     self.model.layer2[1].register_forward_hook(self.forward_hook('layer2.1.relu_2'))

        #     # Hooks for module 6 
        #     self.model.layer3[0].register_forward_hook(self.forward_hook('layer3.0.relu_2'))
        #     self.model.layer3[1].register_forward_hook(self.forward_hook('layer3.1.relu_2'))

        #     # Hooks for module 7
    def forward_hook(self, layer_name):
        def hook(module, input, output):
            self.features[layer_name] = output
        return hook

    def forward(self, x):
        out = self.model(x)
        return out, self.features


if __name__ == '__main__': 
    # cp = torch.load(DATA_PATH / 'r18_test' / 'checkpoint_e0.pth.tar')
    # cp = torch.load(DATA_PATH / 'rn18_1' / 'model_best.pth.tar')

    # for k in cp['state_dict'].keys(): 
    #     model_key = k.replace("module.", "")
    #     model_key = model_key.replace("model.", "")
    #     print(f"Og: {k} Replaced: {model_key}")
    # a = "0, "*5
    # b = "-20,"*15
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha", required=True, type=str)
    args = parser.parse_args() 
    a = "0*10 -5*10 -3*3"
    print(args.alpha)
    alphas = []
    
    # Find all occurrences of a number followed by "*" and another number
    matches = re.findall(r'(-?\d+)\s*\*\s*(-?\d+)', args.alpha)

# Print the matched numbers
    for match in matches:
        alpha = float(match[0])
        multiplier = int(match[1]) 
        alphas.extend([alpha]*multiplier)
    
    print(alphas)

    # for match in matches: 
    #     index = match.start()
    #     alpha = float(a[index-1]) 
    #     print("alpha", alpha)
    #     multiplier = int(a[index+1]) 
    #     alphas.extend([alpha]*multiplier)
    #     print(index)
    
    # print(alphas)


    # cs1 = utils.load_file(DATA_PATH / 'temp' / 'cs_dict_r50new')
    # cs2 = utils.load_file(DATA_PATH / 'temp' / 'cs_dict_r50_new2')
    # cs2 = utils.load_file(DATA_PATH / 'r18_test' / 'cs_dict_val_cp0')
    # print(cs2[4][0])
    # mods = cs2.keys() 
    # for k in mods: 
    #     for bn in (cs2[k].keys()): 
    #         # arr1 = cs1[k][bn]
    #         arr2 = cs2[k][bn]
    #         print(arr2.shape)
    #         # print(arr1.shape, arr2.shape)
    #         # print(np.allclose(arr1, arr2, atol=1e-3)) 
    #         # if not np.allclose(arr1, arr2): 
    #         #     print(np.mean(arr1), np.mean(arr2))
    #         #     print("-----")
    

